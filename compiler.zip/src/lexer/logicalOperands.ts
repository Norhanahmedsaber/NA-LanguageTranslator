export default [
    "||",
    "&&"
]