export default [
    "+",
    "-",
    "*",
    "/"
]