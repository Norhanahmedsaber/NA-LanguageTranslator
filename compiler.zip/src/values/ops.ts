enum Ops {
    "+",
    "-",
    "*",
    "/"
}
export default Ops